//
//  MockStorageRepository.swift
//  CountryInfo
//
//  Created by Dilip Rajendran on 1/30/26.
//

@testable import CountryInfo
import SwiftData

final class MockStorageRepository: StorageRepositoryProtocol {
    var saved: [SavedCountry] = []

    func fetchAll() -> [SavedCountry] {
        saved
    }

    func isIdExisting(id: String) -> Bool {
        saved.contains { $0.officialName == id }
    }

    func toggleSave(savedCountry: SavedCountry) {
        if let index = saved.firstIndex(where: {
            $0.officialName == savedCountry.officialName
        }) {
            saved.remove(at: index)
        } else {
            saved.append(savedCountry)
        }
    }


    func deleteSaved(id: String) {
        saved.removeAll { $0.officialName == id }
    }

    func addCountry(savedCountry: SavedCountry) {
        saved.append(savedCountry)
    }
}
