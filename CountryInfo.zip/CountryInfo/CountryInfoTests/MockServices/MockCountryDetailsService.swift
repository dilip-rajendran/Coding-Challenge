//
//  MockCountryDetailsService.swift
//  CountryInfo
//
//  Created by Dilip Rajendran on 1/30/26.
//

@testable import CountryInfo

final class MockCountryDetailsService: CountryDetailsServiceProtocol {
    let result: Result<[CountryDetailsModel], Error>

    init(result: Result<[CountryDetailsModel], Error>) {
        self.result = result
    }

    func fetchCountryDetails(country: String) async throws -> [CountryDetailsModel] {
        try result.get()
    }
}
