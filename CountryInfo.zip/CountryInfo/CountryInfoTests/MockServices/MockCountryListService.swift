//
//  MockCountryListService.swift
//  CountryInfo
//
//  Created by Dilip Rajendran on 1/30/26.
//

@testable import CountryInfo

final class MockCountryListService: CountryListServiceProtocol {

    enum Result {
        case success([Country])
        case failure(Error)
    }

    var result: Result

    init(result: Result) {
        self.result = result
    }

    func fetchCountriesList() async throws -> [Country] {
        switch result {
        case .success(let countries):
            return countries
        case .failure(let error):
            throw error
        }
    }
}
