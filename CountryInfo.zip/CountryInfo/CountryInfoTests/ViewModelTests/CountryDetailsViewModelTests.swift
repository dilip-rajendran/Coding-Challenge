//
//  CountryDetailsViewModelTests.swift
//  CountryInfo
//
//  Created by Dilip Rajendran on 1/30/26.
//
import XCTest
import SwiftData
@testable import CountryInfo


@MainActor
final class CountryDetailsViewModelTests: XCTestCase {

    private var storage = MockStorageRepository()

    override func setUp() {
        super.setUp()
    }
    
    func test_fetchCountyDetails_success_setsCountryDetails() async {
        let model = CountryDetailsModel.mock()

        let vm = CountryDetailsViewModel(
            service: MockCountryDetailsService(result: .success([model])),
            country: "India",
            isBookMarked: false,
            storageRepository: storage
        )

        await vm.fetchCountyDetails()

        XCTAssertEqual(vm.countryDetails?.name?.common, "India")
    }

    func test_fetchCountyDetails_failure_doesNotCrash() async {
        enum TestError: Error { case failed }

        let vm = CountryDetailsViewModel(
            service: MockCountryDetailsService(result: .failure(TestError.failed)),
            country: "India",
            isBookMarked: false,
            storageRepository: storage
        )

        await vm.fetchCountyDetails()

        XCTAssertNil(vm.countryDetails)
    }


    func test_toggleSave_whenNotSaved_addsCountry_andSetsBookmarked() async {
       
        let model = CountryDetailsModel.mock()

        let vm = CountryDetailsViewModel(
            service: MockCountryDetailsService(result: .success([model])),
            country: "India",
            isBookMarked: false,
            storageRepository: storage
        )

        vm.countryDetails = model

        await vm.toggleSave(officialName: (model.name?.official!)!)

        XCTAssertTrue(vm.isBookMarked)
        XCTAssertEqual(storage.saved.count, 1)
        XCTAssertEqual(storage.saved.first?.officialName, model.name?.official)
    }

    func test_toggleSave_whenAlreadySaved_deletesCountry_andUnbookmarks() async {
        let model = CountryDetailsModel.mock()
        storage.addCountry(savedCountry: SavedCountry(
            commonName: (model.name?.common)!,
            officialName: (model.name?.official)!,
            flagURL: model.flags?.png,
            capital: "New Delhi"
        ))
        

        let vm = CountryDetailsViewModel(
            service: MockCountryDetailsService(result: .success([model])),
            country: "India",
            isBookMarked: true,
            storageRepository: storage
        )

        vm.countryDetails = model

        await vm.toggleSave(officialName: (model.name?.official)!)

        XCTAssertFalse(vm.isBookMarked)
        XCTAssertTrue(storage.saved.isEmpty)
    }

    func test_toggleSave_whenCountryDetailsNil_doesNothing() async {

        let vm = CountryDetailsViewModel(
            service: MockCountryDetailsService(result: .success([])),
            country: "India",
            isBookMarked: false,
            storageRepository: storage
        )

        await vm.toggleSave(officialName: "Republic of India")

        XCTAssertFalse(vm.isBookMarked)
        XCTAssertTrue(storage.saved.isEmpty)
    }
}
