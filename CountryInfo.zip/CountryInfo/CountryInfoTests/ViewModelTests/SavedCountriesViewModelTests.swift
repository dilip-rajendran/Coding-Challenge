//
//  SavedCountriesViewModelTests.swift
//  CountryInfo
//
//  Created by Dilip Rajendran on 1/30/26.
//

import XCTest
@testable import CountryInfo

@MainActor
final class SavedCountriesViewModelTests: XCTestCase {

    private var storage: MockStorageRepository!
    private var viewModel: SavedCountriesViewModel!

    override func setUp() {
        super.setUp()
        storage = MockStorageRepository()
        viewModel = SavedCountriesViewModel(storageRepository: storage)
    }


    func test_init_startsWithEmptyState() {
        XCTAssertTrue(viewModel.savedCountries.isEmpty)
        XCTAssertTrue(viewModel.filteredCountries.isEmpty)
        XCTAssertEqual(viewModel.searchText, "")
    }

    // MARK: - Load Saved Countries

    func test_loadSavedCountries_populatesSavedAndFiltered() async {
        let saved = [
            SavedCountry(
                commonName: "India",
                officialName: "Republic of India",
                flagURL: URL(string: "https://test.com")!,
                capital: "New Delhi"
            ),
            SavedCountry(
                commonName: "France",
                officialName: "French Republic",
                flagURL: URL(string: "https://test.com")!,
                capital: "Paris"
            )
        ]

        storage.saved = saved

        await viewModel.loadSavedCountries()

        XCTAssertEqual(viewModel.savedCountries.count, 2)
        XCTAssertEqual(viewModel.filteredCountries.count, 2)
    }


    func test_search_emptyText_returnsAllCountries() async {
        storage.saved = [
            SavedCountry(
                commonName: "India",
                officialName: "Republic of India",
                flagURL: URL(string: "https://test.com")!,
                capital: "New Delhi"
            )
        ]

        await viewModel.loadSavedCountries()

        viewModel.searchText = ""
        viewModel.search()

        XCTAssertEqual(viewModel.filteredCountries.count, 1)
    }

    func test_search_whitespace_returnsAllCountries() async {
        storage.saved = [
            SavedCountry(
                commonName: "India",
                officialName: "Republic of India",
                flagURL: URL(string: "https://test.com")!,
                capital: "New Delhi"
            )
        ]

        await viewModel.loadSavedCountries()

        viewModel.searchText = "   "
        viewModel.search()

        XCTAssertEqual(viewModel.filteredCountries.count, 1)
    }

    func test_search_matchesCommonName() async {
        storage.saved = [
            SavedCountry(
                commonName: "India",
                officialName: "Republic of India",
                flagURL: URL(string: "https://test.com")!,
                capital: "New Delhi"
            ),
            SavedCountry(
                commonName: "France",
                officialName: "French Republic",
                flagURL: URL(string: "https://test.com")!,
                capital: "Paris"
            )
        ]

        await viewModel.loadSavedCountries()

        viewModel.searchText = "fra"
        viewModel.search()

        XCTAssertEqual(viewModel.filteredCountries.count, 1)
        XCTAssertEqual(viewModel.filteredCountries.first?.commonName, "France")
    }

    func test_search_matchesOfficialName() async {
        storage.saved = [
            SavedCountry(
                commonName: "India",
                officialName: "Republic of India",
                flagURL: URL(string: "https://test.com")!,
                capital: "New Delhi"
            )
        ]

        await viewModel.loadSavedCountries()

        viewModel.searchText = "republic"
        viewModel.search()

        XCTAssertEqual(viewModel.filteredCountries.count, 1)
    }


    func test_deleteSaved_removesCountryAndReloads() async {
        let saved = SavedCountry(
            commonName: "India",
            officialName: "Republic of India",
            flagURL: URL(string: "https://test.com")!,
            capital: "New Delhi"
        )

        storage.saved = [saved]
        await viewModel.loadSavedCountries()

        XCTAssertEqual(viewModel.savedCountries.count, 1)

        await viewModel.deleteSaved(country: saved)

        XCTAssertTrue(viewModel.savedCountries.isEmpty)
        XCTAssertTrue(viewModel.filteredCountries.isEmpty)
    }
}
