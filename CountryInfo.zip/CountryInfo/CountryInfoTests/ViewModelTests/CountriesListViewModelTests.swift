//
//  CountriesListViewModelTests.swift
//  CountryInfo
//
//  Created by Dilip Rajendran on 1/30/26.
//

import XCTest
import SwiftData
@testable import CountryInfo

@MainActor
final class CountriesListViewModelTests: XCTestCase {

    private var storage = MockStorageRepository()

    override func setUp() {
        super.setUp()
    }

    func test_init_loadsSavedCountries() async {
        let saved = SavedCountry(
            commonName: "India",
            officialName: "Republic of India",
            flagURL: URL(string: "https://test.com")!,
            capital: "New Delhi"
        )


        let vm = CountriesListViewModel(
            service: MockCountryListService(result: .success([])),
            storageRepository: storage
        )
        let contry = Country(flags: Flags(png: saved.flagURL), name: Name(common: saved.commonName, official: saved.officialName), capital: ["New Delhi"])
        await vm.toggleSave(country: contry)
        XCTAssertEqual(vm.savedCountries.count, 1)
        XCTAssertEqual(vm.savedCountries.first?.officialName, "Republic of India")
    }


    func test_fetchCountries_success_sortsAlphabetically() async {
        let contry = Country(flags: Flags(png: URL(string: "https://test.com")!), name: Name(common: "Zimbabwe", official: "Republic of Zimbabwe"), capital: ["New Delhi"])
        let second = Country(flags: Flags(png: URL(string: "https://test.com")!), name: Name(common: "Argentina", official: "Argentine Republic"), capital: ["New Delhi"])
        let countries = [
            contry,second
        ]

        let vm = CountriesListViewModel(
            service: MockCountryListService(result: .success(countries)),
            storageRepository: storage
        )

        await vm.fetchCountries()

        XCTAssertEqual(vm.countries.first?.name?.common, "Argentina")
        XCTAssertEqual(vm.filteredCountries.count, 2)
    }

    func test_fetchCountries_failure_doesNotCrash() async {
        let vm = CountriesListViewModel(
            service: MockCountryListService(result: .failure(URLError(.badServerResponse))),
            storageRepository: storage
        )

        await vm.fetchCountries()

        XCTAssertTrue(vm.countries.isEmpty)
        XCTAssertTrue(vm.filteredCountries.isEmpty)
    }

@MainActor
    func test_search_emptyText_returnsAllCountries() async {
            let vm = CountriesListViewModel(
                service: MockCountryListService(result: .success([])),
                storageRepository: storage
            )

            vm.countries = [
                Country.mock(common: "India", official: "Republic of India"),
                Country.mock(common: "France", official: "French Republic")
            ]

            vm.searchText = ""
            vm.search()

            XCTAssertEqual(vm.filteredCountries.count, 2)
        }
    
@MainActor
    func test_search_matchesCommonName() async {
            let vm = CountriesListViewModel(
                service: MockCountryListService(result: .success([])),
                storageRepository: storage
            )

            vm.countries = [
                Country.mock(common: "India", official: "Republic of India"),
                Country.mock(common: "France", official: "French Republic")
            ]

            vm.searchText = "fra"
            vm.search()

            XCTAssertEqual(vm.filteredCountries.count, 1)
            XCTAssertEqual(vm.filteredCountries.first?.name?.common, "France")

    }
    
@MainActor
    func test_search_matchesOfficialName() async {
        let vm = CountriesListViewModel(
            service: MockCountryListService(result: .success([])),
            storageRepository: storage
        )
        vm.countries = [
            Country.mock(common: "India", official: "Republic of India")
        ]

        vm.searchText = "republic"
        vm.search()

        XCTAssertEqual(vm.filteredCountries.count, 1)
    }

@MainActor
    func test_isSaved_returnsTrueIfCountrySaved() async {
        let country = Country.mock(common: "India", official: "Republic of India")

        let saved = SavedCountry(
            commonName: "India",
            officialName: "Republic of India",
            flagURL: URL(string: "https://test.com")!,
            capital: "New Delhi"
        )


        let vm = CountriesListViewModel(
            service: MockCountryListService(result: .success([])),
            storageRepository: storage
        )
        await vm.storageRepository.addCountry(savedCountry: saved)
        await vm.loadSavedCountries()
        XCTAssertTrue(vm.isSaved(country: country))
    }

    func test_toggleSave_addsAndRemovesCountry() async {
        let country = Country.mock(common: "India", official: "Republic of India")

        let vm = CountriesListViewModel(
            service: MockCountryListService(result: .success([])),
            storageRepository: storage
        )

        await vm.toggleSave(country: country)
        XCTAssertEqual(vm.savedCountries.count, 1)
        XCTAssertTrue(vm.isSaved(country: country))

        await vm.toggleSave(country: country)
        XCTAssertEqual(vm.savedCountries.count, 0)
        XCTAssertFalse(vm.isSaved(country: country))
    }
}
