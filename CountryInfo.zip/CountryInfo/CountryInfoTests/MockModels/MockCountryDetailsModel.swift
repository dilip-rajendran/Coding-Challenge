//
//  MockCountryDetailsModel.swift
//  CountryInfo
//
//  Created by Dilip Rajendran on 1/30/26.
//

@testable import CountryInfo
import Foundation

extension CountryDetailsModel {
    static func mock(
        common: String = "India",
        official: String = "Republic of India",
        capital: [String]? = ["New Delhi"],
        population: Int = 1_400_000_000
    ) -> CountryDetailsModel {

        CountryDetailsModel(
            name: Name(
                common: common,
                official: official
            ),
            currencies: [
                "INR": Currency(symbol: "₹", name: "Indian Rupee")
            ],
            capital: capital,
            region: "Asia",
            subregion: "Southern Asia",
            languages: [
                "hin": "Hindi",
                "eng": "English"
            ],
            population: population,
            car: Car(
                signs: ["IND"],
                side: "left"
            ),
            timezones: ["UTC+05:30"],
            flags: FlagImages(
                png: URL(string: "https://flagcdn.com/w320/in.png")!
            ),
            coatOfArms: CoatOfArms(
                png: "https://mainfacts.com/media/images/coats_of_arms/in.png"
            )
        )
    }
}
