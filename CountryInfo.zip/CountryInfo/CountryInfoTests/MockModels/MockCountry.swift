//
//  MockCountry.swift
//  CountryInfo
//
//  Created by Dilip Rajendran on 1/30/26.
//

@testable import CountryInfo
import Foundation

extension Country {
    static func mock(
        common: String,
        official: String,
        capital: String = "Capital"
    ) -> Country {
        Country(
            flags: .init(png: URL(string: "https://test.com/flag.png")!),
            name: .init(common: common, official: official),
            capital: [capital]
        )
    }
}
