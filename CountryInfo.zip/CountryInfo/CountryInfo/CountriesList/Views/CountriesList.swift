//
//  CountriesList.swift
//  CountryInfo
//
//  Created by Dilip Rajendran on 1/27/26.
//

import SwiftUI

public struct CountriesList: View {
    @StateObject private var viewModel: CountriesListViewModel
    @State var path: NavigationPath = NavigationPath()
    @State private var isSearching: Bool = false

    init(viewModel: CountriesListViewModel) {
        self._viewModel = StateObject(wrappedValue: viewModel)
    }
    public var body: some View {
        NavigationStack(path: $path) {
            if viewModel.isFetching {
                loaderView()
            } else {
                List {
                    if viewModel.isSearching {
                            loaderView()
                        }
                    else {
                        ForEach(viewModel.filteredCountries) { country in
                            ZStack {
                                NavigationLink(value: country) {
                                    EmptyView()
                                }
                                .opacity(0)
                                .buttonStyle(.plain)
                                CountryListRow(commonName: country.name?.common,
                                               officialName: country.name?.official,
                                               capital: country.capital?.first ?? Constants.notAvailable,
                                               flagUrl: country.flags?.png,
                                               isBookMarked: viewModel.isSaved(country: country)) {
                                    Task{
                                        await viewModel.toggleSave(country: country)
                                    }
                                    
                                }
                            }
                            .listRowSeparator(.hidden)
                            .listRowInsets(EdgeInsets(top: 10, leading: 10, bottom: 10, trailing: 10))
                        }
                    }
                }
                .navigationDestination(for: Country.self) { country in
                    if let countryOfficial = country.name?.official {
                        CountryDetails(viewModel: CountryDetailsViewModel(service: CountryDetailsService(), country: countryOfficial,
                                                                          isBookMarked: viewModel.isSaved(country: country),
                                                                          storageRepository: viewModel.storageRepository))
                        .toolbar(.hidden, for: .tabBar)
                    }
                }
                .clipped()
                .navigationTitle(Constants.countriesListTitle)
                .navigationBarTitleDisplayMode(.inline)
                .scrollContentBackground(.hidden)
                .listStyle(.plain)
                .searchable(text: $viewModel.searchText, isPresented: $isSearching, placement: .navigationBarDrawer(displayMode: .always), prompt: Text(Constants.countriesListTitle))
                .task(id: viewModel.searchText) {
                    await viewModel.search()
                }
                Spacer()
            }
            }
        .task {
            let _ = await viewModel.fetchCountries()
        }
        .onChange(of: path) {
            Task {
                await viewModel.loadSavedCountries()
                viewModel.searchText = ""
                isSearching = false
            }
        }
        .onAppear() {
            Task {
                await viewModel.loadSavedCountries()
                viewModel.searchText = ""
                isSearching = false
            }
        }
        .errorAlert(errorMessage: .constant(viewModel.errorString))
    }
    @ViewBuilder
    private func loaderView() -> some View {
        HStack {
            Spacer()
            ProgressView()
            Spacer()
        }
    }
}
