//
//  CountryListService.swift
//  CountryInfo
//
//  Created by Dilip Rajendran on 1/27/26.
//

import Foundation

public protocol CountryListServiceProtocol {
    func fetchCountriesList() async throws -> [Country]
    func searchCountry(searchQuery: String) async throws -> [Country]
}

public class CountryListService: CountryListServiceProtocol {
    
    public func fetchCountriesList() async throws -> [Country] {
        guard let url = ApiRoutes.listCountries.url else { throw CountryListServiceErrors.badUrl }

        let (data, response) = try await URLSession.shared.data(from: url)

        guard let response = response as? HTTPURLResponse,
              (200...299).contains(response.statusCode) else {
            throw CountryListServiceErrors.networkError(reason: response.debugDescription)
        }
        do {
            return try JSONDecoder().decode([Country].self, from: data)
        }
        catch {
            throw CountryListServiceErrors.decodingError(reason: error.localizedDescription)
        }

    }
    
    public func searchCountry(searchQuery: String) async throws -> [Country] {
        guard let url = ApiRoutes.searchCountries(searchQuery: searchQuery).url else { throw CountryListServiceErrors.badUrl }
        let (data, response) = try await URLSession.shared.data(from: url)
        guard let httpResponse = response as? HTTPURLResponse,
              (200...299).contains(httpResponse.statusCode) else {
            throw CountryListServiceErrors.networkError(reason: response.debugDescription)
        }
        do {
            return try JSONDecoder().decode([Country].self, from: data)
        }
        catch {
            throw CountryListServiceErrors.decodingError(reason: error.localizedDescription)
        }
    }
}
