//
//  CountryListService.swift
//  CountryInfo
//
//  Created by Dilip Rajendran on 1/27/26.
//

import Foundation

public protocol CountryListServiceProtocol {
    func fetchCountriesList() async throws -> [Country]
}

public class CountryListService: CountryListServiceProtocol {
    private let apiURL = ApiRoutes.listCountries.url
    
    public func fetchCountriesList() async throws -> [Country] {
        guard let url = apiURL else { throw CountryListServiceErrors.badUrl }

        let (data, response) = try await URLSession.shared.data(from: url)

        guard let response = response as? HTTPURLResponse,
              (200...299).contains(response.statusCode) else {
            throw CountryListServiceErrors.networkError(reason: response.debugDescription)
        }
        do {
            return try JSONDecoder().decode([Country].self, from: data)
        }
        catch {
            throw CountryListServiceErrors.decodingError(reason: error.localizedDescription)
        }

    }
}
