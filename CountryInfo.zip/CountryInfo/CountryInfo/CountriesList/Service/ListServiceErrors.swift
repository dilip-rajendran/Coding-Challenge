//
//  ListServiceErrors.swift
//  CountryInfo
//
//  Created by Dilip Rajendran on 1/29/26.
//

import Foundation

public enum CountryListServiceErrors: Error {
    case networkError(reason: String)
    case decodingError(reason: String)
    case badUrl
}

extension CountryListServiceErrors: LocalizedError {
    public var errorDescription: String? {
        switch self {
        case .networkError(let reason):
            return "Network Error: \(reason)"
        case .decodingError(let reason):
            return "Decoding Error: \(reason)"
        case .badUrl:
            return "Invalid URL"
        }
    }
}
