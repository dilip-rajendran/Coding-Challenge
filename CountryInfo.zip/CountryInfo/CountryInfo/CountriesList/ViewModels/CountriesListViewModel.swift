//
//  CountriesListViewModel.swift
//  CountryInfo
//
//  Created by Dilip Rajendran on 1/27/26.
//

import Foundation
import Combine
import SwiftData

@MainActor
final class CountriesListViewModel: ObservableObject {
    
    @Published var searchText = ""
    @Published var filteredCountries: [Country] = []
    @Published var savedCountries: [SavedCountry] = []
    @Published private(set) var errorString: String? = nil
    @Published private(set) var isSearching: Bool = false
    @Published private(set) var isFetching: Bool = false
    @Published private(set) var savedCountryIDs: Set<String> = []

    var countries: [Country] = []

    let storageRepository: StorageRepositoryProtocol
    private let service: CountryListServiceProtocol
    
    init(service: CountryListServiceProtocol, storageRepository: StorageRepositoryProtocol) {
        self.service = service
        self.storageRepository = storageRepository
    }
    func loadSavedCountries() async {
        savedCountries = await storageRepository.fetchAll()
        savedCountryIDs = Set(savedCountries.map { $0.officialName })
    }
    
    func fetchCountries() async {
        isFetching = true
        defer { isFetching = false }
        do {
            let fetchedCountries = try await service.fetchCountriesList()
            countries = fetchedCountries.sorted(by: { $0.name?.common?.localizedCaseInsensitiveCompare($1.name?.common ?? "") == .orderedAscending })
            filteredCountries = countries
            errorString = nil
        }
        catch {
            errorString = error.localizedDescription
        }
    }
    
    func search() async {
        try? await Task.sleep(nanoseconds: 400_000_000)
        guard !Task.isCancelled else { return }
        isSearching = true
        defer { isSearching = false }
        let trimmed = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard trimmed.count >= 2 else {
            filteredCountries = countries
            return
        }
        do {
            let results = try await service.searchCountry(searchQuery: trimmed)
            filteredCountries = results
        } catch {
            filteredCountries = []
        }
    }

     func isSaved(country: Country) -> Bool {
         guard let officialName = country.name?.official else { return false }
         return savedCountryIDs.contains(officialName)
     }
    
    func toggleSave(country: Country) async {
        let savedCountry = SavedCountry(commonName: country.name?.common ?? "", officialName: country.name?.official ?? "", flagURL: country.flags?.png ?? URL(string: ""), capital: country.capital?.first ?? Constants.notAvailable
         )
        await storageRepository.toggleSave(savedCountry: savedCountry)
        await loadSavedCountries()
    }
}

