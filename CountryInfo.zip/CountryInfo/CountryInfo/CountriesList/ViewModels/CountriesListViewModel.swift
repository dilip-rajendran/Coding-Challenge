//
//  CountriesListViewModel.swift
//  CountryInfo
//
//  Created by Dilip Rajendran on 1/27/26.
//

import Foundation
import Combine
import SwiftData

@MainActor
final class CountriesListViewModel: ObservableObject {
    
    @Published var countries: [Country] = []
    @Published var searchText = ""
    @Published var filteredCountries: [Country] = []
    @Published var savedCountries: [SavedCountry] = []
    @Published var errorString: String? = nil
    let storageRepository: StorageRepositoryProtocol
    private let service: CountryListServiceProtocol
    
    init(service: CountryListServiceProtocol, storageRepository: StorageRepositoryProtocol) {
        self.service = service
        self.storageRepository = storageRepository
    }
    func loadSavedCountries() async {
        savedCountries = await storageRepository.fetchAll()
    }
    
    func fetchCountries() async {
        do {
            let fetchedCountries = try await service.fetchCountriesList()
            countries = fetchedCountries.sorted(by: { $0.name.common.localizedCaseInsensitiveCompare($1.name.common) == .orderedAscending })
            filteredCountries = countries
            errorString = nil
        }
        catch {
            errorString = error.localizedDescription
        }
    }
    
    func search() {
        let trimmed = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard trimmed.count >= 2 else {
            filteredCountries = countries
            return
        }
        let query = trimmed.lowercased()
        filteredCountries = countries.filter({ country in
            let name = country.name.common.lowercased()
            let official = country.name.official.lowercased()
            return name.contains(query) || official.contains(query)
        })
    }

     func isSaved(country: Country) -> Bool {
         savedCountries.contains( where: {$0.officialName == country.name.official})
    }
    
    func toggleSave(country: Country) async {
         let savedCountry = SavedCountry(commonName: country.name.common, officialName: country.name.official, flagURL: country.flags.png, capital: country.capital.first ?? Constants.notAvailable
         )
        await storageRepository.toggleSave(savedCountry: savedCountry)
        await loadSavedCountries()
    }
}

