//
//  CountryListModel.swift
//  CountryInfo
//
//  Created by Dilip Rajendran on 1/27/26.
//

import Foundation

public struct Country: Codable, Identifiable, Hashable {
    public var id: String { name.official }
    let flags: Flags
    let name: Name
    let capital: [String]
}

public struct Flags: Codable, Equatable, Hashable {
    let png: URL
}

public struct Name: Codable, Equatable, Hashable {
    let common: String
    let official: String
}
