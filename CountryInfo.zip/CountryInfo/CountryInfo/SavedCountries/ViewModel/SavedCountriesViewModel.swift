//
//  SavedCountriesViewModel.swift
//  CountryInfo
//
//  Created by Dilip Rajendran on 1/29/26.
//

import Foundation
import Combine
import SwiftData

@MainActor
final class SavedCountriesViewModel: ObservableObject {
    @Published var savedCountries: [SavedCountry] = []
    @Published var searchText = ""
    @Published var filteredCountries: [SavedCountry] = []
    let storageRepository: StorageRepositoryProtocol

    init(storageRepository: StorageRepositoryProtocol) {
        self.storageRepository = storageRepository
    }
    func loadSavedCountries() async {
        savedCountries = await storageRepository.fetchAll()
        savedCountries = savedCountries.sorted(by: { $0.commonName?.localizedCaseInsensitiveCompare($1.commonName ?? "") == .orderedAscending })
        filteredCountries = savedCountries
    }
    
    func search() {
        let trimmed = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard trimmed.count >= 2 else {
            filteredCountries = savedCountries
            return
        }
        let query = trimmed.lowercased()
        filteredCountries = savedCountries.filter({ country in
            let name = country.commonName?.lowercased()
            let official = country.officialName.lowercased()
            return name?.contains(query) ?? false || official.contains(query)
        })
    }
    
    func deleteSaved(country: SavedCountry) async {
        await storageRepository.toggleSave(savedCountry: country)
        await loadSavedCountries()
   }
}
