//
//  SavedCountriesView.swift
//  CountryInfo
//
//  Created by Dilip Rajendran on 1/29/26.
//

import SwiftUI
import SwiftData

public struct SavedCountriesView: View {
    @StateObject private var viewModel: SavedCountriesViewModel
    @State var path: NavigationPath = NavigationPath()
    @State private var isSearching: Bool = false
    
    init(viewModel: SavedCountriesViewModel) {
        self._viewModel = StateObject(wrappedValue: viewModel)
    }
    public var body: some View {
        NavigationStack(path: $path) {
            List {
                ForEach(viewModel.filteredCountries) { countryItem in
                    ZStack {
                        NavigationLink(value: countryItem) {
                            EmptyView()
                        }
                        .opacity(0)
                        .buttonStyle(.plain)
                        CountryListRow(commonName: countryItem.commonName, officialName: countryItem.officialName, capital: countryItem.capital, flagUrl: countryItem.flagURL, isBookMarked: true) {
                            Task{
                                await viewModel.deleteSaved(country: countryItem)
                            }
                        }
                    }
                    .listRowSeparator(.hidden)
                    .listRowInsets(EdgeInsets(top: 10, leading: 10, bottom: 10, trailing: 10))
                    
                }
                
            }
            
            .clipped()
            .navigationTitle(Constants.savedListTitle)
            .navigationBarTitleDisplayMode(.inline)
            .scrollContentBackground(.hidden)
            .searchable(text: $viewModel.searchText, isPresented: $isSearching, placement: .navigationBarDrawer(displayMode: .always), prompt: Text(Constants.countriesListTitle))
            .onChange(of: viewModel.searchText) {
                viewModel.search()
            }
            .listStyle(.plain)
            .background(Color.white)
            .navigationDestination(for: SavedCountry.self) { countryItem in
                CountryDetails(viewModel: CountryDetailsViewModel(service: CountryDetailsService(),
                                                                  country: countryItem.officialName,
                                                                  isBookMarked: true,
                                                                  storageRepository: viewModel.storageRepository))
                    .toolbar(.hidden, for: .tabBar)
                Spacer()
            }
        }
        .onAppear() {
            Task {
                await viewModel.loadSavedCountries()
                viewModel.searchText = ""
                isSearching = false
            }
        }
        .onChange(of: path) {
            Task {
                await viewModel.loadSavedCountries()
                viewModel.searchText = ""
                isSearching = false
            }
        }
    }
}
