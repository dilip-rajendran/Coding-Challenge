//
//  SavedCountriesModel.swift
//  CountryInfo
//
//  Created by Dilip Rajendran on 1/29/26.
//

import SwiftData
import Foundation

@Model
final class SavedCountry: Equatable, Hashable, Identifiable {
    @Attribute(.unique) var officialName: String
    var commonName: String
    var flagURL: URL
    var capital: String
    var isSaved: Bool = false
    init(
        commonName: String,
        officialName: String,
        flagURL: URL,
        capital: String,
        isSaved: Bool = false
    ) {
        self.commonName = commonName
        self.officialName = officialName
        self.flagURL = flagURL
        self.capital = capital
        self.isSaved = isSaved
    }
}
