//
//  CountryInfoApp.swift
//  CountryInfo
//
//  Created by Dilip Rajendran on 1/27/26.
//

import SwiftUI
import SwiftData

@main
struct CountryInfoApp: App {
    let container = try! ModelContainer(for: SavedCountry.self)
    
    var body: some Scene {
        WindowGroup {
            Home()
        }
        .environment(\.modelContext, container.mainContext)
        .environmentObject(
            AppDependencies(
                storageRepository:
                    StorageRepository(
                        context: container.mainContext
                    )
            )
        )
    }
}
