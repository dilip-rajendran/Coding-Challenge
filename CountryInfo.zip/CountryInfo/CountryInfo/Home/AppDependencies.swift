//
//  AppDependencies.swift
//  CountryInfo
//
//  Created by Dilip Rajendran on 1/29/26.
//

import Foundation
import Combine

final class AppDependencies: ObservableObject {
    let storageRepository: StorageRepository

    init(storageRepository: StorageRepository) {
        self.storageRepository = storageRepository
    }
}
