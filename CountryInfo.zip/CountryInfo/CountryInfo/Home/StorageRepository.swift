//
//  StorageRepository.swift
//  CountryInfo
//
//  Created by Dilip Rajendran on 1/29/26.
//

import SwiftData
import Foundation

protocol StorageRepositoryProtocol {
    func fetchAll() async -> [SavedCountry]
    func toggleSave(savedCountry: SavedCountry) async
    func isIdExisting(id: String) async -> Bool
    func addCountry(savedCountry: SavedCountry) async
    func deleteSaved(id: String) async
}

@MainActor
final class StorageRepository: StorageRepositoryProtocol {

    private let context: ModelContext

    init(context: ModelContext) {
        self.context = context
    }

    func fetchAll() async -> [SavedCountry] {
        let descriptor = FetchDescriptor<SavedCountry>()
        return (try? context.fetch(descriptor)) ?? []
    }

    func isIdExisting(id: String) async -> Bool {
        let savedCountries = await fetchAll()
        return savedCountries.first(where: {
            $0.officialName == id
        }) != nil
    }

    func deleteSaved(id: String) async {
        let savedCountries = await fetchAll()
        guard let savedCountry = savedCountries.first(where: {
            $0.officialName == id
        })  else { return }
        
        context.delete(savedCountry)
        try? context.save()
    }
    
    func addCountry(savedCountry: SavedCountry) async {
        context.insert(
            savedCountry
        )
        try? context.save()
    }
    
    func toggleSave(savedCountry: SavedCountry) async {
        let savedCountries = await fetchAll()
        if let existing = savedCountries.first(where: {
            $0.officialName == savedCountry.officialName
        }) {
            context.delete(existing)
        } else {
            context.insert(
                savedCountry
            )
        }
         try? context.save()
    }
}
