//
//  Home.swift
//  CountryInfo
//
//  Created by Dilip Rajendran on 1/27/26.
//

import SwiftUI
import SwiftData

struct Home: View {
    @EnvironmentObject private var deps: AppDependencies

    var body: some View {
        TabView {
            Tab(Constants.countriesListTitle, systemImage: Constants.countriesListTab) {
                CountriesList(viewModel: CountriesListViewModel(service: CountryListService(), storageRepository: deps.storageRepository))
            }
            Tab(Constants.savedListTitle, systemImage: Constants.savedListTab) {
                SavedCountriesView(viewModel: SavedCountriesViewModel(storageRepository: deps.storageRepository))
            }
        }
    }
}

#Preview {
    Home()
}
