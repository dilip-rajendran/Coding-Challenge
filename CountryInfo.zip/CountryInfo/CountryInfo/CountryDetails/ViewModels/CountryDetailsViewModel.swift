//
//  CountryDetailsViewModel.swift
//  CountryInfo
//
//  Created by Dilip Rajendran on 1/28/26.
//

import Foundation
import Combine
import SwiftData

@MainActor
public class CountryDetailsViewModel: ObservableObject {
    private let service: CountryDetailsServiceProtocol
    private let country: String
    @Published var countryDetails: CountryDetailsModel?
    @Published var isBookMarked: Bool = false
    @Published var errorString: String? = nil

    private var savedCountries: [SavedCountry] = []
    private let storageRepository: StorageRepositoryProtocol
    
    init(service: CountryDetailsServiceProtocol, country: String, isBookMarked: Bool, storageRepository: StorageRepositoryProtocol) {
        self.service = service
        self.country = country
        self.storageRepository = storageRepository
        self.isBookMarked = isBookMarked
    }
    
    func fetchCountyDetails() async {
        do
        {
            let countryDetailsResponse =  try await service.fetchCountryDetails(country: country).first
            countryDetails = countryDetailsResponse
            errorString = nil
        }
        catch {
            errorString = error.localizedDescription
        }
    }
    
    func loadSavedCountries() async {
        savedCountries = await storageRepository.fetchAll()
    }
    func getTimeZoneTitle() -> String {
        return (countryDetails?.timezones.count ?? 1) == 1 ? "Timezone" : "Timezone(s)"
    }
    func toggleSave(officialName: String) async {
        await loadSavedCountries()
        if await storageRepository.isIdExisting(id: officialName) {
            await storageRepository.deleteSaved(id: officialName)
            isBookMarked = false
        } else {
            if let countryDetails = countryDetails {
                let savedCountry = SavedCountry(commonName: countryDetails.name.common, officialName: countryDetails.name.official, flagURL: countryDetails.flags.png, capital: countryDetails.capital?.first ?? Constants.notAvailable
                )
                await storageRepository.addCountry(savedCountry: savedCountry)
                isBookMarked = true
            }
        }
   }
}

