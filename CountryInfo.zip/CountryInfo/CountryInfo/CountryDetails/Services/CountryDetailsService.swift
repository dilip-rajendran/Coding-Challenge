//
//  CountryDetailsService.swift
//  CountryInfo
//
//  Created by Dilip Rajendran on 1/28/26.
//

import Foundation

public protocol CountryDetailsServiceProtocol {
    func fetchCountryDetails(country: String) async throws -> [CountryDetailsModel]
}

public class CountryDetailsService: CountryDetailsServiceProtocol {
    public func fetchCountryDetails(country: String) async throws -> [CountryDetailsModel] {
        guard let url = ApiRoutes.countryDetails(name: country).url else { throw CountryDetailsServiceErrors.badUrl }
        let (data, response) = try await URLSession.shared.data(from: url)
        guard let httpResponse = response as? HTTPURLResponse,
              (200...299).contains(httpResponse.statusCode) else {
            throw CountryDetailsServiceErrors.networkError(reason: response.debugDescription)
        }
        do {
            return try JSONDecoder().decode([CountryDetailsModel].self, from: data)
        }
        catch {
            throw CountryListServiceErrors.decodingError(reason: error.localizedDescription)
        }
    }
}
