//
//  CountryDetailsModel.swift
//  CountryInfo
//
//  Created by Dilip Rajendran on 1/28/26.
//

import Foundation

public struct CountryDetailsModel: Codable {
    let name: Name
    let currencies: [String: Currency]?
    let capital: [String]?
    let region: String
    let subregion: String?
    let languages: [String: String]?
    let population: Int
    let car: Car
    let timezones: [String]
    let flags: FlagImages
    let coatOfArms: CoatOfArms?
}

struct Currency: Codable {
    let symbol: String?
    let name: String
}

struct Car: Codable {
    let signs: [String]?
    let side: String
}

struct FlagImages: Codable {
    let png: URL
}

struct CoatOfArms: Codable {
    let png: String?
}
