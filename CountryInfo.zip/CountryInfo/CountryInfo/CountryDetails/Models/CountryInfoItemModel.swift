//
//  CountryInfoItemModel.swift
//  CountryInfo
//
//  Created by Dilip Rajendran on 1/28/26.
//

enum CountryInfoItems: String, CaseIterable, Identifiable {
    case timeZone
    case population
    case languages
    case currencies
    case carDriveSide
    case coatOfArms
    var id: String { self.rawValue }
}
