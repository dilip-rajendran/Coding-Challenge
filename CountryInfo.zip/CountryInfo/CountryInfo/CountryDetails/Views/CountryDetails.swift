//
//  CountryDetails.swift
//  CountryInfo
//
//  Created by Dilip Rajendran on 1/28/26.
//

import SwiftUI
import SwiftData

public struct CountryDetails: View {
    @StateObject private var viewModel: CountryDetailsViewModel
    @Query private var savedCountries: [SavedCountry]
    

    let columns = [
            GridItem(.flexible(), spacing: 16),
            GridItem(.flexible(), spacing: 16)
        ]
    private let cardHeight: CGFloat = 120
    init(viewModel: CountryDetailsViewModel) {
        self._viewModel = StateObject(wrappedValue: viewModel)
    }
    public var body: some View {
        GeometryReader { dimension in
            ScrollView {
                VStack(alignment: .leading) {
                    ZStack(alignment: .bottomLeading) {
                        FlagAsyncImageView(
                            url: viewModel.countryDetails?.flags.png,
                            width: dimension.size.width,
                            height: dimension.size.height * 0.3
                        )
                        buildCountyNameView()
                    }
                    Spacer()
                        .frame(height: 70)
                    HStack(alignment: .top) {
                        buildRegionView(key: Constants.region, value: viewModel.countryDetails?.region ?? Constants.notAvailable, showDivider: true)
                        buildRegionView(key: Constants.subregion, value: viewModel.countryDetails?.subregion ?? Constants.notAvailable, showDivider: true)
                        buildRegionView(key: Constants.capital, value: viewModel.countryDetails?.capital?.first ?? Constants.notAvailable)
                    }
                    .padding(.top, 10)
                    .cardBackground()
                    .padding(.horizontal, 15)
                    LazyVGrid(columns: columns) {
                        ForEach(CountryInfoItems.allCases) { infoItem in
                            infoItemView(for: infoItem)
                        }
                    }
                    .padding()
                }
                .errorAlert(errorMessage: $viewModel.errorString)
            }
        }
        
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    Task {
                        await viewModel.toggleSave(officialName: viewModel.countryDetails?.name.official ?? "")
                    }
                } label: {
                    Image(systemName: viewModel.isBookMarked ? Constants.bookmarkfill : Constants.bookmark)
                }
            }
        }
        .task {
            await viewModel.fetchCountyDetails()
        }
    }
    
    @ViewBuilder
    private func buildRegionView(key: String, value: String, showDivider: Bool = false) -> some View {
            Spacer()
            VStack(alignment: .center, spacing: 10) {
                Text(key).font(.headline)
                Text(value)
            }
            Spacer()
            if showDivider {
                Divider().frame(width: 2, height: 40).overlay(Color.secondary).padding(.top, 20).padding(.bottom, 5)
            }
    }
    
    @ViewBuilder
    private func infoItemView(for item: CountryInfoItems) -> some View {
        switch item {
        case .timeZone:
            InfoItemView(title: viewModel.getTimeZoneTitle(), height: cardHeight) {
                BulletList(items: viewModel.countryDetails?.timezones ?? [])
            }
        case .population:
            InfoItemView(title: "Population", height: cardHeight) {
                Text(viewModel.countryDetails?.population.formatted() ?? "")
                    .font(.subheadline)
    
            }
        case .languages:
            InfoItemView(title: "Languages", height: cardHeight) {
                BulletList(items: viewModel.countryDetails?.languages?.values.sorted() ?? [])
            }
        case .currencies:
            InfoItemView(title: "Currencies", height: cardHeight) {
                CurrencyView(currencies: viewModel.countryDetails?.currencies)
            }
        case .carDriveSide:
            InfoItemView(title: "Car Drive Side", height: cardHeight) {
                DriveSideView(side: viewModel.countryDetails?.car.side ?? "right")
            }
        case .coatOfArms:
            InfoItemView(title: "Coat of Arms", height: cardHeight) {
                CoatOfArmsView(url: viewModel.countryDetails?.coatOfArms?.png)
            }
        }
    }
    
    @ViewBuilder
    private func buildCountyNameView() -> some View {
        GroupBox {
            VStack {
                Text(viewModel.countryDetails?.name.common ?? "")
                    .font(.title)
                    .bold()
                Text(viewModel.countryDetails?.name.official ?? "")
                    .font(.headline)
            }
        }
        .compositingGroup()
        .shadow(radius: 5)
        .offset(x: 20 ,y: 50)
    }
}
