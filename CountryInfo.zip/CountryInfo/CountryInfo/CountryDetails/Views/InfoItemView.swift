//
//  InfoItemView.swift
//  Info
//
//  Created by Dilip Rajendran on 1/28/26.
//

import SwiftUI

struct InfoItemView<Content: View>: View {
    let title: String
    let height: CGFloat
    @ViewBuilder let content: Content

    var body: some View {
        VStack(alignment: .center, spacing: 12) {
            Text(title)
                .font(.headline)
            content
                .frame(maxHeight: .infinity, alignment: .top)
                
        }
        .padding()
        .frame(
            maxWidth: .infinity,
            minHeight: height,
            maxHeight: height,
            alignment: .top
        )
        .clipped()
        .cardBackground()
    }
}

struct BulletList: View {
    let items: [String]

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            ForEach(items.prefix(2), id: \.self) { item in
                Text("• \(item)")
                    .font(.subheadline)
            }
            if items.count > 2 {
                Text("• …")
                    .foregroundColor(.secondary)
                
            }
        }
    }
}

struct CurrencyView: View {
    let currencies: [String: Currency]?
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            ForEach(currencies?.keys.sorted() ?? [], id: \.self) { key in
                if let currency = currencies?[key] {
                    Text("\(key) (\(currency.symbol ?? "")) \(currency.name)")
                        .font(.subheadline)
                }
            }
        }
    }
}

struct DriveSideView: View {
    let side: String

    var body: some View {
        HStack(spacing: 12) {
            Text("LEFT")
                .foregroundColor(side == "left" ? .primary : .secondary)

            Image(systemName: "car.circle")
                .resizable()
                .frame(width: 30, height: 30)
                .scaledToFit()

            Text("RIGHT")
                .foregroundColor(side == "right" ? .primary : .secondary)
        }
        .font(.subheadline)
    }
}

struct CoatOfArmsView: View {
    let url: String?

    var body: some View {
        AsyncImage(url: URL(string: url ?? "")) { image in
            image
                .resizable()
                .scaledToFit()
        } placeholder: {
            ProgressView()
        }
        .frame(height: 60)
    }
}
