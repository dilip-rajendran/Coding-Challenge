//
//  Extensions.swift
//  CountryInfo
//
//  Created by Dilip Rajendran on 1/28/26.
//

import SwiftUI

extension View {
    func cardBackground(
        cornerRadius: CGFloat = 16,
        shadowOpacity: Double = 0.1,
        shadowRadius: CGFloat = 8,
        shadowYOffset: CGFloat = 4
    ) -> some View {
        modifier(
            CardBackgroundModifier(
                cornerRadius: cornerRadius,
                shadowOpacity: shadowOpacity,
                shadowRadius: shadowRadius,
                shadowYOffset: shadowYOffset
            )
        )
    }
}

extension View {
    func errorAlert(errorMessage: Binding<String?>) -> some View {
        self.modifier(ErrorAlertModifier(errorMessage: errorMessage))
    }
}
