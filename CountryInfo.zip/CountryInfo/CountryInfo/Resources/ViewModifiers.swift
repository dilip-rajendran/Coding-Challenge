//
//  ViewModifiers.swift
//  CountryInfo
//
//  Created by Dilip Rajendran on 1/28/26.
//

import SwiftUI

struct CardBackgroundModifier: ViewModifier {
    let cornerRadius: CGFloat
    let shadowOpacity: Double
    let shadowRadius: CGFloat
    let shadowYOffset: CGFloat

    func body(content: Content) -> some View {
        content
            .background(
                RoundedRectangle(cornerRadius: cornerRadius)
                    .fill(Color(.systemBackground))
                    .shadow(
                        color: .black.opacity(shadowOpacity),
                        radius: shadowRadius,
                        y: shadowYOffset
                    )
            )
    }
}

struct ErrorAlertModifier: ViewModifier {
    @Binding var errorMessage: String?

    func body(content: Content) -> some View {
        content
            .alert("Error", isPresented: Binding(
                get: { errorMessage != nil },
                set: { newValue in
                    if !newValue { errorMessage = nil }
                }
            )) {
                Button("OK", role: .cancel) {}
            } message: {
                if let message = errorMessage {
                    Text(message)
                }
            }
    }
}
