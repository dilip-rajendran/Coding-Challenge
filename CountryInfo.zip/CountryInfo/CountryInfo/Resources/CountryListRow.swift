//
//  CountryListRow.swift
//  CountryInfo
//
//  Created by Dilip Rajendran on 1/28/26.
//

import SwiftUI

public struct CountryListRow: View {
    let commonName: String?
    let officialName: String?
    let capital: String?
    let flagUrl: URL?
    let flagWidth: CGFloat = 100
    let flagHeight: CGFloat = 70
    var isBookMarked: Bool = false
    let onBookmarkTap: () -> Void

    
    public var body: some View {
        GroupBox {
            HStack(alignment: .top) {
                FlagAsyncImageView(
                    url: flagUrl,
                    width: 100,
                    height: 70
                )
                Spacer().frame(width: 10)
                VStack(alignment: .leading) {
                    Text(commonName ?? "")
                        .font(.headline)
                    Text(officialName ?? "")
                        .font(.subheadline)
                    Text(capital ?? "")
                        .font(.caption)
                        .foregroundStyle(Color.secondary)
                }
                Spacer()
                Button("", systemImage: isBookMarked ? Constants.bookmarkfill: Constants.bookmark) {
                    onBookmarkTap()
                }
            }
        }
        .compositingGroup()
        .backgroundStyle(Color.white)
        .shadow(color: Color.black.opacity(0.1), radius: 2, x: -1, y: -1)
        .shadow(color: Color.black.opacity(0.4), radius: 2, x: 2, y: 3)
    }
}
