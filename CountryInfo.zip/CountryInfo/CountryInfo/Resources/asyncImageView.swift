//
//  FlagAsyncImageView.swift
//  CountryInfo
//
//  Created by Dilip Rajendran on 1/28/26.
//

import SwiftUI

struct asyncImageView: View {
    let url: URL?
    let width: CGFloat
    let height: CGFloat
    let emptyImage: String
    
    var body: some View {
        if let url = url {
            AsyncImage(url: url) { phase in
                switch phase {
                case .empty:
                    ProgressView()
                        .frame(width: width, height: height)
                    
                case .success(let image):
                    image
                        .resizable()
                        .frame(width: width, height: height)
                        .scaledToFit()
                    
                case .failure:
                    Image(systemName: emptyImage)
                        .resizable()
                        .frame(width: width, height: height)
                        .scaledToFit()
                        .foregroundColor(.secondary)
                    
                @unknown default:
                    EmptyView()
                        .frame(width: width, height: height)
                }
            }
        } else {
            Image(systemName: emptyImage)
                .resizable()
                .frame(width: width, height: height)
                .scaledToFit()
                .foregroundColor(.secondary)
        }
    }
}
