//
//  ApiRoutes.swift
//  CountryInfo
//
//  Created by Dilip Rajendran on 1/30/26.
//

import Foundation

enum ApiRoutes {
    case listCountries
    case countryDetails(name: String)
    
       var url: URL? {
           switch self {
           case .countryDetails(let countryName):
               return URL(string: "https://restcountries.com/v3.1/name/\(countryName)")
           case .listCountries:
               return URL(string: "https://restcountries.com/v3.1/all?fields=name,flags,capital")
           }
       }
}
