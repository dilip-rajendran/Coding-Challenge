//
//  ApiRoutes.swift
//  CountryInfo
//
//  Created by Dilip Rajendran on 1/30/26.
//

import Foundation

enum ApiRoutes {
    case listCountries
    case searchCountries(searchQuery: String)
    case countryDetails(name: String)
    
       var url: URL? {
           switch self {
           case .countryDetails(let countryName):
               guard var components = URLComponents(string: "https://restcountries.com/v3.1/name/\(countryName)") else { return nil }
                   components.queryItems = [
                       URLQueryItem(name: "fields", value: "name,capital,flags,region,subregion,population,timezones,currencies,car,coatOfArms,languages")
                   ]
               return components.url

           case .listCountries:
               guard var components = URLComponents(string: "https://restcountries.com/v3.1/all?fields=name,flags,capital") else { return nil }
                   components.queryItems = [
                       URLQueryItem(name: "fields", value: "name,capital,flags")
                   ]
               return components.url

           case .searchCountries(let searchQuery):
               guard var components = URLComponents(string: "https://restcountries.com/v3.1/name/\(searchQuery)") else { return nil }
                   components.queryItems = [
                       URLQueryItem(name: "fields", value: "name,capital,flags,region,subregion,population,timezones,currencies,car,coatOfArms,languages")
                   ]
               return components.url
           }
       }
}
