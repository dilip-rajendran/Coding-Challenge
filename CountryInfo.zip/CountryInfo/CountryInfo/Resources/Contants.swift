//
//  Contants.swift
//  CountryInfo
//
//  Created by Dilip Rajendran on 1/29/26.
//

enum Constants {
    static let countriesListTitle = "Search"
    static let savedListTitle = "Saved"
    static let countriesListTab = "magnifyingglass"
    static let savedListTab = "star"
    static let notAvailable = "N/A"
    static let region = "Region"
    static let subregion = "Subregion"
    static let capital = "Capital"
    static let bookmarkfill = "bookmark.fill"
    static let bookmark = "bookmark"
}
