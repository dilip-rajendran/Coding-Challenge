//
//  FlagAsyncImageView.swift
//  CountryInfo
//
//  Created by Dilip Rajendran on 1/28/26.
//

import SwiftUI

struct FlagAsyncImageView: View {
    let url: URL?
    let width: CGFloat
    let height: CGFloat

    var body: some View {
        AsyncImage(url: url) { phase in
            switch phase {
            case .empty:
                ProgressView()
                    .frame(width: width, height: height)

            case .success(let image):
                image
                    .resizable()
                    .frame(width: width, height: height)
                    .scaledToFit()

            case .failure:
                Image(systemName: "flag.slash.fill")
                    .resizable()
                    .frame(width: width, height: height)
                    .scaledToFit()
                    .foregroundColor(.secondary)

            @unknown default:
                EmptyView()
                    .frame(width: width, height: height)
            }
        }
    }
}
